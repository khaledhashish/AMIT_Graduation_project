/*
 * Project_Slave.c
 *
 * Created: 11/24/2020 4:19:05 PM
 * Author : khaled
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "shortcuts.h"
#include "Timer.h"
#include "SPI.h"

#define LED_RED		2
#define LED_BLUE	7
#define FAN			3


int main(void)
{
	DDRB |= (1<<6);
	DDRB &= ~(1<<4);
	DDRB &= ~(1<<5);
	DDRB &= ~(1<<7);
	DDRC |= (1<<LED_BLUE) | (1<<LED_RED);
	DDRD=(1<<FAN);
	SPI_inti(0);
    while (1) 
    {
		char order=SPI_Slave_Resive();
		if(order ==('F'))setPinD(FAN);
		else if(order ==('E'))resetPinD(FAN);
		else if(order ==('B'))setPinC(LED_BLUE);
		else if(order ==('R'))setPinC(LED_RED);
		else if(order ==('Q'))resetPinC(LED_BLUE);
		else if(order ==('W'))resetPinC(LED_RED);
		else if(order ==('O')){
						resetPinC(LED_BLUE);
						resetPinC(LED_RED);
		}

	}
}
