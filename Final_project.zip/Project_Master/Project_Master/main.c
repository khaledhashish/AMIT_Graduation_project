/*
 * Project_Master.c
 *
 * Created: 11/24/2020 3:16:33 PM
 * Author : khaled
 */ 
#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include "shortcuts.h"
#include "Timer.h"
#include "UART.h"
#include "SPI.h"
#include "ADC.h"

int main(void)
{
	DDRB |= (1<<4) | (1<<5) | (1<<7);
	DDRB &= ~(1<<6);
	sei();
    UART_inti();
	SPI_inti(1);
	ADC_init(0,1,7);
	Timer0_init(0,5,0,0);
    while (1) 
    {
		SPI_Master_Send(UART_READ());
    }
}

ISR(TIMER0_OVF_vect){
	static int i=0;
	static int temp=0;
	i++;
	if(i==15){
		ADC_StartConv();
		UART_SEND_num(ADC_read());
		UART_SEND('\r');
		if ((ADC_read()>=300) & (temp<300))
		{
			SPI_Master_Send('F');
		}
		else if((ADC_read()<300) & (temp>=300)){
			SPI_Master_Send('E');
		}
		temp=ADC_read();
		i=0;
	}
}